import shutil, os

def pack(basepath, sourcepath, foldername, destpath, newfoldername=None):
	if newfoldername == None:
		newfoldername = foldername
	print("\t"+sourcepath+foldername)
	print("\t^-> " + destpath+newfoldername+".zip")
	print("\t...")
	shutil.make_archive(basepath+destpath+newfoldername, 'zip', basepath+sourcepath+foldername+"/")

base_path = ""
sourcepath = ""
packpath = ""

print("\nrunning with base_path= " + base_path + "\n")
try:
	#
	pack(base_path, sourcepath, "", packpath)
	#
	pack(base_path, sourcepath, "", packpath)
	#
	print()
	sitepackpath = base_path + "sites/"
	print("packing websites to sites folder for my archive...")
	pack(base_path, sourcepath, "sites/", "")
	pack(base_path, sourcepath, "sites/", "")
	print("All done.")
except Exception as e:
	print()
	print("!!! Exception !!!")
	print(e)
else:
	pass
finally:
	input("\nPress Enter To Close..")